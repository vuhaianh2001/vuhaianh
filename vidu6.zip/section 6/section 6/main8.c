#include <stdio.h>
void main(){
 int i;
 float x;
 char c;
 scanf("%3d %5f %c",&i,&x, &c);
}