#include <stdio.h>
void main()
{
 char letter;
 printf("\nPlease enter any character : ");
 letter = getchar();
 printf("\nThe character entered by you is %c . ", letter);
}