#include <stdio.h>
void main(){
 putchar('H'); putchar('\n');
 putchar('\t');
 putchar('E'); putchar('\n');
 putchar('\t'); putchar('\t');
 putchar('L'); putchar('\n');
 putchar('\t'); putchar('\t'); putchar('\t');
 putchar('L'); putchar('\n');
 putchar('\t'); putchar('\t'); putchar('\t');
 putchar('\t');
 putchar('O');
}