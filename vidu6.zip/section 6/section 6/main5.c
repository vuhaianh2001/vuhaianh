#include <stdio.h>
void main()
{
 int a = 80;
 char b= 'C';
 printf("\nThis is the number stored in 'a' %d",a);
 printf("\nThis is a character interpreted from 'a' %c",a);
 printf("\nThis is also a character stored in 'b' %c",b);
 printf("\nHey!the character of 'b' is printed as a number!%d",b);
}
